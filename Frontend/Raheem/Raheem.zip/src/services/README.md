Add endpoint-specific services here once FastAPI endpoint contracts are confirmed. Do not assume task URLs or payload formats.
