import { Routes, Route } from 'react-router-dom';
import Header from '../components/layout/Header';
import Footer from '../components/layout/Footer';
import MobileNavigation from '../components/layout/MobileNavigation';
import HomePage from '../pages/HomePage';
import GatewayPage from '../pages/GatewayPage';
import NotFoundPage from '../pages/NotFoundPage';

export default function App() {
  return <div className="bg-surface font-body-md text-body-md text-on-surface antialiased min-h-screen selection:bg-secondary-fixed selection:text-on-secondary-fixed flex flex-col justify-between">
    <Header />
    <Routes>
      <Route path="/" element={<HomePage />} />
      <Route path="/:slug" element={<GatewayPage />} />
      <Route path="*" element={<NotFoundPage />} />
    </Routes>
    <MobileNavigation />
    <Footer />
  </div>;
}
